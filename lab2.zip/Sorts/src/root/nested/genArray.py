'''
Created on 12 May 2014

@author: Nicholas Branfield
'''
def genArray(size):
    import random
    return [random.randint(1, 65536) for _ in range(size)]