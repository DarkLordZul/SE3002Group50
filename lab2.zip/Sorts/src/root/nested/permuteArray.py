'''
Created on 12 May 2014

@author: Nicholas Branfield
'''
def permuteArray(arr):
    import random
    
    random.shuffle(arr)
    return arr