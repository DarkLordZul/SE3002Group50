'''
Created on 12 May 2014

@author: zealot
'''
def printArray(title, arr, timeTaken):
    print("{} took {:.10f} seconds".format(title, timeTaken))
    for n in range(0, len(arr), 10):
        print("\t".join(map(str, arr[n:n + 10])))
    print("*"*78)
    
def printTable(times):
    print("Sorting of 10,000 integers using the following algorithms:\n")
    print("{:<15} {:<25}".format("Algorithm", "Time (seconds)"))
    print("--"*15)
    for i in range(0, 3):
        print("{:<15} {:<25.10f}".format(times["Algorithm"][i], times["Time (seconds)"][i]))
    print("--"*15)
