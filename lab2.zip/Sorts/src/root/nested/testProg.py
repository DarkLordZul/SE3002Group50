'''
Created on 12 May 2014

@author: zealot
'''
import unittest

from root.nested.bubbleSort import bubbleSort
from root.nested.genArray import genArray
from root.nested.heapSort import heapSort
from root.nested.permuteArray import permuteArray
from root.nested.printArray import printArray, printTable
from root.nested.quickSort import quickSort


class Test(unittest.TestCase):

    def testPartTwo(self):
        from timeit import default_timer as timer
        times = {"Algorithm": ["quickSort", "heapSort", "bubbleSort"], "Time (seconds)": [0.0, 0.0, 0.0]}
        
        print("$"*78)
        print("BEGIN partTwo n = 10,000")
    
        size = 10000
        A = genArray(size)

        start = timer()
        A = quickSort(A)
        timeTaken = timer() - start
        times["Time (seconds)"][0] = timeTaken
    
        A = permuteArray(A)
    
        start = timer()
        A = heapSort(A)
        timeTaken = timer() - start
        times["Time (seconds)"][1] = timeTaken
    
        A = permuteArray(A)
    
        start = timer()
        A = bubbleSort(A)
        timeTaken = timer() - start
        times["Time (seconds)"][2] = timeTaken
    
        printTable(times)
        
        print("END TEST2")
        print("$"*78)
        pass

    def testProg(self):
        from timeit import default_timer as timer
        
        print("BEGIN testProg n = 100")
        
        start = timer()
        size = 100
        A = genArray(size)
        timeTaken = timer() - start
        printArray("Generating Original set", A, timeTaken)

        start = timer()
        A = quickSort(A)
        timeTaken = timer() - start
        printArray("Quick Sort", A, timeTaken)
    
        A = permuteArray(A)
    
        start = timer()
        A = heapSort(A)
        timeTaken = timer() - start
        printArray("Heap Sort", A, timeTaken)
    
        A = permuteArray(A)
    
        start = timer()
        A = bubbleSort(A)
        timeTaken = timer() - start
        printArray("Bubble Sort", A, timeTaken)
       
        print("END OF TEST1")
        print("$"*78)
        pass

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()